# Simulador de Custos - Guarujá
Este projeto Streamlit simula custos de transporte entre rotas do terminal de Guarujá.