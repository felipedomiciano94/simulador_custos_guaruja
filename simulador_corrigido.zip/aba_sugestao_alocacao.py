import streamlit as st
import pandas as pd

def aplicar_depara(df, depara_df, col, chave_origem='ORIGEM', chave_destino='PADRONIZADO'):
    mapa = dict(zip(depara_df[chave_origem], depara_df[chave_destino]))
    return df[col].map(mapa).fillna(df[col])

def render_sugestao_alocacao(upload_base=None, upload_precos=None):
    st.subheader("🚛 Sugestão de Alocação de Frota / Agregado")
    precos_df = pd.DataFrame([
        {'ORIGEM': 'GUARUJÁ/SP', 'DESTINO': 'ADAMANTINA/SP', 'CUSTO_AGREGADO': 8856.75, 'CUSTO_FROTA': 11480.85},
        {'ORIGEM': 'GUARUJÁ/SP', 'DESTINO': 'ADOLFO/SP', 'CUSTO_AGREGADO': 7424.97, 'CUSTO_FROTA': 10010.23},
    ])
    st.write(precos_df)